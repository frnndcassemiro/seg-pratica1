Prática 1 CI1030 - ERE2
Professor: André Grégio
Aluna: Fernanda Cassemiro Pereira GRR20163078

Execução esperada:
    python3 T1p1a.py AV1.txt
    python3 T1p1b.py AV2.txt
    python3 T1p2.py community.rules sid-msg.map

Arquivos de saída:
    T1p1a.txt
    T1p1b.txt
    T1p2.txt

Arquivos de erro:
    T1p1a_erros.txt -> a primeira linha do arquivo AV1.txt foge do padrão estabelecido
    T1p1b_erros.txt -> deve ser gerado vazio
    T1p2_erros.txt -> o cabeçalho do arquivo community.rules não é interpretado 




